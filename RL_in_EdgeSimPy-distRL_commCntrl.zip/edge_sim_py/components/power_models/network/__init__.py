"""Automatic Python configuration file."""
__version__ = "1.1.0"

# Network power models
from .conterato_network_power_model import ConteratoNetworkPowerModel
