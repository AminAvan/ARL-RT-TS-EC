"""Automatic Python configuration file."""
__version__ = "1.1.0"


# Network switch builders
from .sample_switch import sample_switch
