from edge_sim_py.dataset_generator import *

"""
Creating datasets
"""


print(jetson_nano().model_name)