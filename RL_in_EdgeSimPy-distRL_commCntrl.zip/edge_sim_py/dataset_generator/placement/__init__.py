"""Automatic Python configuration file."""
__version__ = "1.1.0"

# Container registry placement strategies
from .container_registries import *

# Service placement strategies
from .services import *
