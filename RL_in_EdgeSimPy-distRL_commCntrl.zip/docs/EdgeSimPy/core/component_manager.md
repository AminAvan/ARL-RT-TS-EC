# Component Manager 

::: edge_sim_py.ComponentManager