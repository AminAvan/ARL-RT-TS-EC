# Network Link

::: edge_sim_py.components.NetworkLink