# Edge Server

::: edge_sim_py.components.EdgeServer