# Service

::: edge_sim_py.components.Service