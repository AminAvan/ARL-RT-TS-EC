# Square

::: edge_sim_py.components.power_models.servers.square_server_power_model
