# Linear

::: edge_sim_py.components.power_models.servers.linear_server_power_model
