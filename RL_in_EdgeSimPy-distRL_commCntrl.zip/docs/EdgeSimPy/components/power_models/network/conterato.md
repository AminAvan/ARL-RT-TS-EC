# Conterato

::: edge_sim_py.components.power_models.network.conterato_network_power_model
