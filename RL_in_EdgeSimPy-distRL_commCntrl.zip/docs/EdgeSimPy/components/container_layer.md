# Container Layer

::: edge_sim_py.components.ContainerLayer