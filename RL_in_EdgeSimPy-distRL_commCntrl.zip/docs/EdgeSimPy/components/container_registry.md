# Container Registry

::: edge_sim_py.components.ContainerRegistry