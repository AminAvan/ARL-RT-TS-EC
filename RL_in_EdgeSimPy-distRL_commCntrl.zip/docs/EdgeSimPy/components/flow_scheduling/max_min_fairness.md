# Max Min Fairness

::: edge_sim_py.components.flow_scheduling.max_min_fairness
