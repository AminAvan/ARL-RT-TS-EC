# Circular

::: edge_sim_py.components.user_access_patterns.CircularDurationAndIntervalAccessPattern