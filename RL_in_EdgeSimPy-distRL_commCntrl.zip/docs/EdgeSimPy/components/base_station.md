# Base Station

::: edge_sim_py.components.BaseStation