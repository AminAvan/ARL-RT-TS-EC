# Application

::: edge_sim_py.components.Application