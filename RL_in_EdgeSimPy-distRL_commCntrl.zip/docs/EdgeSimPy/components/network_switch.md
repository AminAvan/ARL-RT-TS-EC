# Network Switch

::: edge_sim_py.components.NetworkSwitch